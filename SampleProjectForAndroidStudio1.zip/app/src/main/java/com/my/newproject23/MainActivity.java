package com.my.newproject23;

import android.app.Activity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import java.io.InputStream;
import android.content.Intent;
import android.net.Uri;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.DialogFragment;


public class MainActivity extends  Activity { 
	
	
	private HashMap<String, Object> m = new HashMap<>();
	
	private RequestNetwork r;
	private RequestNetwork.RequestListener _r_request_listener;
	private Calendar SKUPC = Calendar.getInstance();
	private AlertDialog.Builder d;
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		r = new RequestNetwork(this);
		d = new AlertDialog.Builder(this);
		
		_r_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
				m = new Gson().fromJson(_response.substring((int)(20), (int)(_response.length() - 2)), new TypeToken<HashMap<String, Object>>(){}.getType());
				
				String time = m.get("time").toString();
				
				String[] timeparts = time.split("/");
				String part1 = timeparts[0];
				String part2 = timeparts[1];
				String part3 = timeparts[2];
				String part4 = timeparts[3];
				String part5 = timeparts[4];
				
				double uptime = Double.parseDouble(part1.concat(part2.concat(part3.concat(part4.concat(part5)))));
				
				
				SKUPC = Calendar.getInstance();
				
				double ctime = Double.parseDouble(new SimpleDateFormat("yyyy").format(SKUPC.getTime()).concat(new SimpleDateFormat("M").format(SKUPC.getTime()).concat(new SimpleDateFormat("d").format(SKUPC.getTime()).concat(new SimpleDateFormat("H").format(SKUPC.getTime()).concat(new SimpleDateFormat("m").format(SKUPC.getTime()))))));
				
				if((uptime == ctime)||(uptime <= ctime)) {
					d.setTitle(m.get("title").toString());
					d.setMessage(m.get("description").toString());
					d.setPositiveButton(m.get("mainBtnTxt").toString(), new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							i.setAction(Intent.ACTION_VIEW);
							i.setData(Uri.parse(m.get("mainBtn").toString()));
							startActivity(i);
						}
					});
					if (m.get("isExtraBtn").toString().equals("true")) {
						d.setNegativeButton(m.get("extraBtnTxt").toString(), new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								
							}
						});
					}
					d.create().show();
				}else{}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		r.startRequestNetwork(RequestNetworkController.GET, "https://sketchupdate.tk/data.php/?appId=aim_15963657", "", _r_request_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}