package com.my.newproject23;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import android.app.Activity;
import android.content.SharedPreferences;
import java.util.Calendar;
import java.text.SimpleDateFormat;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.bumptech.glide.Glide;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class MainActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private HashMap<String, Object> SKUPMap = new HashMap<>();
	
	private RequestNetwork r;
	private RequestNetwork.RequestListener _r_request_listener;
	private SharedPreferences SKUP;
	private Calendar SKUPC = Calendar.getInstance();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		r = new RequestNetwork(this);
		SKUP = getSharedPreferences("SKUP", Activity.MODE_PRIVATE);
		
		_r_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				_SketchUpdate_Component_v1(_response, "abc@gmail.com");
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		r.startRequestNetwork(RequestNetworkController.GET, "https://sketchupdate.tk/data.php/?appId=aim_15963657", "", _r_request_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _SketchUpdate_Component_v1 (final String _response, final String _UniqueId) {
		SKUPMap = new Gson().fromJson(_response.substring((int)(20), (int)(_response.length() - 2)), new TypeToken<HashMap<String, Object>>(){}.getType());
		if (SKUPMap.get("sendTo").toString().equals("all") || SKUPMap.get("sendTo").toString().contains(_UniqueId)) {
			String titleColor = SKUPMap.get("titleColor").toString();
			
			String descriptionColor= SKUPMap.get("descriptionColor").toString();
			
			String backColor = SKUPMap.get("backColor").toString();
			
			String mainBtnTxtColor = SKUPMap.get("mainBtnTxtColor").toString();
			
			String mainBtnBackColor = SKUPMap.get("mainBtnBackColor").toString();
			
			String extraBtnTxtColor = SKUPMap.get("extraBtnTxtColor").toString();
			
			String extraBtnBackColor = SKUPMap.get("extraBtnBackColor").toString();
			
			double btnRadius = Double.parseDouble(SKUPMap.get("btnRadius").toString());
			
			double radius = Double.parseDouble(SKUPMap.get("radius").toString());
			
			String currentVersion = "1.0";
			String time = SKUPMap.get("time").toString();
			
			String[] timeparts = time.split("/");
			String part1 = timeparts[0];
			String part2 = timeparts[1];
			String part3 = timeparts[2];
			String part4 = timeparts[3];
			String part5 = timeparts[4];
			
			double uptime = Double.parseDouble(part1.concat(part2.concat(part3.concat(part4.concat(part5)))));
			
			
			SKUPC = Calendar.getInstance();
			
			double ctime = Double.parseDouble(new SimpleDateFormat("yyyy").format(SKUPC.getTime()).concat(new SimpleDateFormat("M").format(SKUPC.getTime()).concat(new SimpleDateFormat("d").format(SKUPC.getTime()).concat(new SimpleDateFormat("H").format(SKUPC.getTime()).concat(new SimpleDateFormat("m").format(SKUPC.getTime()))))));
			if((uptime == ctime)||(uptime <= ctime)) {
				try{
					android.content.pm.PackageInfo packageInfo = this.getPackageManager().getPackageInfo(getPackageName(), 0);
					
					currentVersion = packageInfo.versionName;
				}
				catch (android.content.pm.PackageManager.NameNotFoundException e) {showMessage(e.toString());}
				
				
				if (SKUPMap.get("alertType").toString().equals("dialog1") || SKUPMap.get("alertType").toString().equals("sheet1")) {
					LinearLayout layllout = new LinearLayout(this);
					
					layllout.setOrientation(LinearLayout.VERTICAL);
					layllout.setGravity(Gravity.TOP | Gravity.LEFT);
					
					layllout.setPadding(20,20,20,20);
					
					LinearLayout main = new LinearLayout(this);
					
					main.setOrientation(LinearLayout.VERTICAL);
					
					main.setGravity(Gravity.TOP | Gravity.LEFT);
					main.setPadding(40,40,40,40);
					
					android.graphics.drawable.GradientDrawable skup1 = new android.graphics.drawable.GradientDrawable();
					skup1.setColor(Color.parseColor(backColor));
					skup1.setCornerRadius((float)radius);
					main.setBackground(skup1);
					layllout.addView(main);
					
					final TextView title = new TextView(this);
					title.setLayoutParams(new LinearLayout.LayoutParams(250,55, 0.0f));
					title.setText(SKUPMap.get("title").toString());
					title.setTextSize((int)20);
					title.setTypeface(null, Typeface.BOLD);
					
					title.setTextColor(Color.parseColor(titleColor));
					
					TextView subtitle = new TextView(this);
					subtitle.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
					
					subtitle.setGravity(Gravity.CENTER_VERTICAL | Gravity.CENTER_HORIZONTAL);
					subtitle.setText(SKUPMap.get("subtitle").toString());
					subtitle.setTextSize((int)16);
					
					LinearLayout gap1 = new LinearLayout(this);
					gap1.setOrientation(LinearLayout.VERTICAL);
					
					gap1.setLayoutParams(new LinearLayout.LayoutParams(90,40, 0.0f));
					
					final TextView description = new TextView(this);
					description.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
					
					description.setGravity(Gravity.TOP | Gravity.LEFT);
					description.setText(SKUPMap.get("description").toString());
					
					description.setTextSize((int)16);
					
					description.setTextColor(Color.parseColor(descriptionColor));
					
					LinearLayout gap2 = new LinearLayout(this);
					gap2.setOrientation(LinearLayout.VERTICAL);
					
					gap2.setLayoutParams(new LinearLayout.LayoutParams(90,40, 0.0f));
					
					LinearLayout lineear1 = new LinearLayout(this);
					lineear1.setOrientation(LinearLayout.HORIZONTAL);
					lineear1.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
					
					lineear1.setGravity(Gravity.TOP | Gravity.RIGHT);
					
					lineear1.setPadding(20,8,0,20);
					
					Button no = new Button(this);
					no.setText(SKUPMap.get("extraBtnTxt").toString());
					no.setTextSize((int)14);
					
					android.graphics.drawable.GradientDrawable skup01 = new android.graphics.drawable.GradientDrawable();
					skup01.setColor(Color.parseColor(extraBtnBackColor));
					skup01.setCornerRadius((float)btnRadius);
					no.setBackground(skup01);
					no.setTextColor(Color.parseColor(extraBtnTxtColor));
					
					LinearLayout.LayoutParams params0 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,      
					LinearLayout.LayoutParams.WRAP_CONTENT);
					params0.setMargins(8, 0, 0, 20);
					no.setLayoutParams(params0);
					LinearLayout gap = new LinearLayout(this);
					gap.setOrientation(LinearLayout.VERTICAL);
					
					gap.setLayoutParams(new LinearLayout.LayoutParams(20,20, 0.0f));
					Button yes = new Button(this);
					yes.setText(SKUPMap.get("mainBtnTxt").toString());
					yes.setTextSize((int)14);
					
					android.graphics.drawable.GradientDrawable skup02 = new android.graphics.drawable.GradientDrawable();
					skup02.setColor(Color.parseColor(mainBtnBackColor));
					skup02.setCornerRadius((float)btnRadius);
					yes.setBackground(skup02);
					yes.setTextColor(Color.parseColor(mainBtnTxtColor));
					
					LinearLayout.LayoutParams params00 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,      
					LinearLayout.LayoutParams.WRAP_CONTENT);
					params00.setMargins(0, 0, 0, 20);
					yes.setLayoutParams(params00);
					if (SKUPMap.get("isExtraBtn").toString().equals("true")) {
						lineear1.addView(no, 0);
						lineear1.addView(gap, 1);
						lineear1.addView(yes, 2);
					}
					else {
						lineear1.addView(gap, 0);
						lineear1.addView(yes, 1);
					}
					
					LinearLayout gap3 = new LinearLayout(MainActivity.this);
					gap3.setOrientation(LinearLayout.VERTICAL);
					
					gap3.setLayoutParams(new LinearLayout.LayoutParams(250,40, 0.0f));
					LinearLayout line = new LinearLayout(MainActivity.this);
					line.setOrientation(LinearLayout.VERTICAL);
					
					line.setLayoutParams(new LinearLayout.LayoutParams(500,3, 0.0f));
					
					line.setBackgroundColor(0xFFCFD8DC);
					LinearLayout gap4 = new LinearLayout(MainActivity.this);
					gap4.setOrientation(LinearLayout.VERTICAL);
					
					gap4.setLayoutParams(new LinearLayout.LayoutParams(250,40, 0.0f));
					
					LinearLayout lineear2 = new LinearLayout(MainActivity.this);
					lineear2.setOrientation(LinearLayout.HORIZONTAL);
					lineear2.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
					
					lineear2.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
					
					lineear2.setPadding(0,0,0,0);
					ImageView logo = new ImageView(MainActivity.this);
					
					logo.setLayoutParams(new LinearLayout.LayoutParams(55,55, 0.0f));
					
					Glide.with(getApplicationContext()).load(Uri.parse(SKUPMap.get("appIcon").toString())).into(logo);
					TextView name = new TextView(MainActivity.this);
					
					name.setText(SKUPMap.get("appName").toString());
					name.setTextSize((int)16);
					name.setTypeface(null, Typeface.BOLD);
					
					name.setPadding(15,0,0,0);
					lineear2.addView(logo, 0);
					lineear2.addView(name, 1);
					
					main.addView(title, 0);
					main.addView(subtitle, 1);
					if (SKUPMap.get("isSubtitle").toString().equals("true")) {
						subtitle.setVisibility(View.VISIBLE);
					}
					else {
						subtitle.setVisibility(View.GONE);
					}
					main.addView(gap1, 2);
					main.addView(description, 3);
					main.addView(gap2, 4);
					main.addView(lineear1, 5);
					
					
					if (SKUPMap.get("isHeader").toString().equals("true")) {
						main.addView(gap3, 6);
						main.addView(line, 7);
						main.addView(gap4, 8);
					}
					else {
						
					}
					
					if (SKUPMap.get("newVersion").toString().equals(currentVersion)) {
							
					}
					else {
							if (SKUPMap.get("isOneTime").toString().equals("true")) {
									if ((SKUP.getString("isOneTime", "").equals(SKUPMap.get("isOneTime").toString()))) {
											
									}
							else {
								SKUP.edit().putString("isOneTime", SKUPMap.get("isOneTime").toString()).commit();
								if (SKUPMap.get("alertType").toString().equals("dialog1")) {
									final Dialog diaalog1 = new Dialog(MainActivity.this);
									diaalog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
									diaalog1.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
									yes.setOnClickListener(new OnClickListener() { 
										public void onClick(View v) 
										{
											if (SKUPMap.get("isCancelable").toString().equals("true")) 
											{ 
												Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
												startActivity(SketchUpdateIntent);
											} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
											{
												Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
												startActivity(SketchUpdateIntent);
												finishAffinity();
											}
										}
									});
									no.setOnClickListener(new OnClickListener() { 
										public void onClick(View v) 
										{
											
											if (SKUPMap.get("extraBtn").toString().equals("exit")) 
											{
												finishAffinity();
											} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
											{    
												diaalog1.dismiss();  
											}
											
										}
									});
									diaalog1.setContentView(layllout);
									if (SKUPMap.get("isCancelable").toString().equals("true")) {
										diaalog1.setCancelable(true);
									}
									else {
										diaalog1.setCancelable(false);
									}
									diaalog1.show();
								}
								else {
									final com.google.android.material.bottomsheet.BottomSheetDialog diaalog2 = new com.google.android.material.bottomsheet.BottomSheetDialog(MainActivity.this);
									yes.setOnClickListener(new OnClickListener() { 
										public void onClick(View v) 
										{
											if (SKUPMap.get("isCancelable").toString().equals("true")) 
											{ 
												Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
												startActivity(SketchUpdateIntent);
											} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
											{
												Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
												startActivity(SketchUpdateIntent);
												finishAffinity();
											}
										}
									});
									no.setOnClickListener(new OnClickListener() { 
										public void onClick(View v) 
										{
											if (SKUPMap.get("extraBtn").toString().equals("exit")) 
											{
												finishAffinity();
											} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
											{    
												diaalog2.dismiss();  
											}
										}
									});
									diaalog2.setContentView(layllout);
									diaalog2.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
									if (SKUPMap.get("isCancelable").toString().equals("true")) {
										diaalog2.setCancelable(true);
									}
									else {
										diaalog2.setCancelable(false);
									}
									diaalog2.show();
								}
							}
						} else 
						if (SKUPMap.get("alertType").toString().equals("dialog1")) {
							final Dialog diaalog1 = new Dialog(MainActivity.this);
							diaalog1.requestWindowFeature(Window.FEATURE_NO_TITLE);
							diaalog1.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
							yes.setOnClickListener(new OnClickListener() { 
								public void onClick(View v) 
								{
									if (SKUPMap.get("isCancelable").toString().equals("true")) 
									{ 
										Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
										startActivity(SketchUpdateIntent);
									} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
									{
										Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
										startActivity(SketchUpdateIntent);
										finishAffinity();
									}
								}
							});
							no.setOnClickListener(new OnClickListener() { 
								public void onClick(View v) 
								{
									if (SKUPMap.get("extraBtn").toString().equals("exit")) 
									{
										finishAffinity();
									} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
									{    
										diaalog1.dismiss();  
									}
								}
							});
							diaalog1.setContentView(layllout);
							if (SKUPMap.get("isCancelable").toString().equals("true")) {
								diaalog1.setCancelable(true);
							}
							else {
								diaalog1.setCancelable(false);
							}
							diaalog1.show();
						}
						else {
							final com.google.android.material.bottomsheet.BottomSheetDialog diaalog2 = new com.google.android.material.bottomsheet.BottomSheetDialog(MainActivity.this);
							yes.setOnClickListener(new OnClickListener() { 
								public void onClick(View v) 
								{
									if (SKUPMap.get("isCancelable").toString().equals("true")) 
									{ 
										Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
										startActivity(SketchUpdateIntent);
									} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
									{
										Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
										startActivity(SketchUpdateIntent);
										finishAffinity();
									}
								}
							});
							no.setOnClickListener(new OnClickListener() { 
								public void onClick(View v) 
								{
									if (SKUPMap.get("extraBtn").toString().equals("exit")) 
									{
										finishAffinity();
									} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
									{    
										diaalog2.dismiss();  
									}
								}
							});
							diaalog2.setContentView(layllout);
							diaalog2.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
							if (SKUPMap.get("isCancelable").toString().equals("true")) {
								diaalog2.setCancelable(true);
							}
							else {
								diaalog2.setCancelable(false);
							}
							diaalog2.show();
						}
					}
				}
				else {
					if (SKUPMap.get("alertType").toString().equals("dialog2") || SKUPMap.get("alertType").toString().equals("sheet2")) {
						LinearLayout layllout2 = new LinearLayout(this);
						
						layllout2.setOrientation(LinearLayout.VERTICAL);
						layllout2.setGravity(Gravity.TOP | Gravity.LEFT);
						
						layllout2.setPadding(20,20,20,20);
						
						LinearLayout main21 = new LinearLayout(this);
						
						main21.setOrientation(LinearLayout.HORIZONTAL);
						
						main21.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
						main21.setPadding(20,20,20,20);
						
						android.graphics.drawable.GradientDrawable skup11 = new android.graphics.drawable.GradientDrawable();
						skup11.setColor(Color.parseColor(backColor));
						skup11.setCornerRadius((float)radius);
						main21.setBackground(skup11);
						
						LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,      
						LinearLayout.LayoutParams.WRAP_CONTENT
						);
						params1.setMargins(0, 0, 0, 20);
						main21.setLayoutParams(params1);
						ImageView logo2 = new ImageView(this);
						
						logo2.setLayoutParams(new LinearLayout.LayoutParams(60,60, 0.0f));
						
						Glide.with(getApplicationContext()).load(Uri.parse(SKUPMap.get("appIcon").toString())).into(logo2);
						
						LinearLayout lineear3 = new LinearLayout(this);
						
						lineear3.setOrientation(LinearLayout.VERTICAL);
						lineear3.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
						
						lineear3.setPadding(20,0,0,0);
						final TextView name2 = new TextView(this);
						
						name2.setLayoutParams(new LinearLayout.LayoutParams(250,45, 0.0f));
						
						name2.setText(SKUPMap.get("appName").toString());
						name2.setTextSize((int)20);
						name2.setTypeface(null, Typeface.BOLD);
						
						name2.setTextColor(Color.parseColor(titleColor));
						TextView subtitle2 = new TextView(this);
						
						subtitle2.setText(SKUPMap.get("subtitle").toString().concat("                                                                 "));
						subtitle2.setTextSize((int)14);
						lineear3.addView(name2, 0);
						lineear3.addView(subtitle2, 1);
						
						main21.addView(logo2, 0);
						main21.addView(lineear3, 1);
						
						LinearLayout main22 = new LinearLayout(this);
						
						main22.setOrientation(LinearLayout.VERTICAL);
						
						main22.setGravity(Gravity.TOP | Gravity.LEFT);
						main22.setPadding(20,28,20,8);
						
						android.graphics.drawable.GradientDrawable skup12 = new android.graphics.drawable.GradientDrawable();
						skup12.setColor(Color.parseColor(backColor));
						skup12.setCornerRadius((float)radius);
						main22.setBackground(skup12);
						final TextView title2 = new TextView(this);
						
						title2.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
						
						title2.setPadding(0,0,0,10);
						
						title2.setText(SKUPMap.get("title").toString());
						title2.setTextSize((int)18);
						title2.setTypeface(null, Typeface.BOLD);
						
						title2.setTextColor(Color.parseColor(titleColor));
						final TextView description2 = new TextView(this);
						
						description2.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
						
						description2.setGravity(Gravity.TOP | Gravity.LEFT);
						
						description2.setText(SKUPMap.get("description").toString());
						
						description2.setTextSize((int)14);
						
						description2.setTextColor(Color.parseColor(descriptionColor));
						Button no2 = new Button(this);
						
						no2.setText(SKUPMap.get("extraBtnTxt").toString());
						no2.setTextSize((int)14);
						
						android.graphics.drawable.GradientDrawable skup13 = new android.graphics.drawable.GradientDrawable();
						skup13.setColor(Color.parseColor(extraBtnBackColor));
						skup13.setCornerRadius((float)btnRadius);
						no2.setBackground(skup13);
						
						no2.setTextColor(Color.parseColor(extraBtnTxtColor));
						
						LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,      
						LinearLayout.LayoutParams.WRAP_CONTENT);
						params2.setMargins(8, 20, 8, 0);
						no2.setLayoutParams(params2);
						Button yes2 = new Button(this);
						
						yes2.setText(SKUPMap.get("mainBtnTxt").toString());
						yes2.setTextSize((int)14);
						
						android.graphics.drawable.GradientDrawable skup14 = new android.graphics.drawable.GradientDrawable();
						skup14.setColor(Color.parseColor(mainBtnBackColor));
						skup14.setCornerRadius((float)btnRadius);
						yes2.setBackground(skup14);
						
						yes2.setTextColor(Color.parseColor(mainBtnTxtColor));
						
						LinearLayout.LayoutParams params3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,      
						LinearLayout.LayoutParams.WRAP_CONTENT);
						params3.setMargins(8, 20, 8, 20);
						yes2.setLayoutParams(params3);
						
						if (SKUPMap.get("isExtraBtn").toString().equals("true")) {
							main22.addView(title2, 0);
							main22.addView(description2, 1);
							main22.addView(no2, 2);
							main22.addView(yes2, 3);
						}
						else {
							main22.addView(title2, 0);
							main22.addView(description2, 1);
							main22.addView(yes2, 2);
						}
						
						if (SKUPMap.get("isHeader").toString().equals("true")) {
							layllout2.addView(main21, 0);
							layllout2.addView(main22, 1);
						}
						else {
							layllout2.addView(main22, 0);
						}
						
						if (SKUPMap.get("newVersion").toString().equals(currentVersion)) {
								
						}
						else {
								if (SKUPMap.get("isOneTime").toString().equals("true")) {
										if ((SKUP.getString("isOneTime", "").equals(SKUPMap.get("isOneTime").toString()))) {
												
										}
								else {
									SKUP.edit().putString("isOneTime", SKUPMap.get("isOneTime").toString()).commit();
									if (SKUPMap.get("alertType").toString().equals("dialog2")) {
										final Dialog diaalog3 = new Dialog(this);
										diaalog3.requestWindowFeature(Window.FEATURE_NO_TITLE);
										diaalog3.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
										yes2.setOnClickListener(new OnClickListener() { 
											public void onClick(View v) 
											{
												if (SKUPMap.get("isCancelable").toString().equals("true")) 
												{ 
													Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
													startActivity(SketchUpdateIntent);
												} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
												{
													Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
													startActivity(SketchUpdateIntent);
													finishAffinity();
												}
											}
										});
										no2.setOnClickListener(new OnClickListener() { 
											public void onClick(View v) 
											{
												
												if (SKUPMap.get("extraBtn").toString().equals("exit")) 
												{
													finishAffinity();
												} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
												{    
													diaalog3.dismiss();  
												}
												
											}
										});
										diaalog3.setContentView(layllout2);
										if (SKUPMap.get("isCancelable").toString().equals("true")) {
											diaalog3.setCancelable(true);
										}
										else {
											diaalog3.setCancelable(false);
										}
										diaalog3.show();
									}
									else {
										final com.google.android.material.bottomsheet.BottomSheetDialog diaalog4 = new com.google.android.material.bottomsheet.BottomSheetDialog(this);
										yes2.setOnClickListener(new OnClickListener() { 
											public void onClick(View v) 
											{
												if (SKUPMap.get("isCancelable").toString().equals("true")) 
												{ 
													Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
													startActivity(SketchUpdateIntent);
												} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
												{
													Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
													startActivity(SketchUpdateIntent);
													finishAffinity();
												}
											}
										});
										no2.setOnClickListener(new OnClickListener() { 
											public void onClick(View v) 
											{
												if (SKUPMap.get("extraBtn").toString().equals("exit")) 
												{
													finishAffinity();
												} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
												{    
													diaalog4.dismiss();  
												}
											}
										});
										diaalog4.setContentView(layllout2);
										diaalog4.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
										if (SKUPMap.get("isCancelable").toString().equals("true")) {
											diaalog4.setCancelable(true);
										}
										else {
											diaalog4.setCancelable(false);
										}
										diaalog4.show();
									}
								}
							} else 
							if (SKUPMap.get("alertType").toString().equals("dialog2")) {
								final Dialog diaalog3 = new Dialog(this);
								diaalog3.requestWindowFeature(Window.FEATURE_NO_TITLE);
								diaalog3.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
								yes2.setOnClickListener(new OnClickListener() { 
									public void onClick(View v) 
									{
										if (SKUPMap.get("isCancelable").toString().equals("true")) 
										{ 
											Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
											startActivity(SketchUpdateIntent);
										} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
										{
											Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
											startActivity(SketchUpdateIntent);
											finishAffinity();
										}
									}
								});
								no2.setOnClickListener(new OnClickListener() { 
									public void onClick(View v) 
									{
										if (SKUPMap.get("extraBtn").toString().equals("exit")) 
										{
											finishAffinity();
										} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
										{    
											diaalog3.dismiss();  
										}
									}
								});
								diaalog3.setContentView(layllout2);
								if (SKUPMap.get("isCancelable").toString().equals("true")) {
									diaalog3.setCancelable(true);
								}
								else {
									diaalog3.setCancelable(false);
								}
								diaalog3.show();
							}
							else {
								final com.google.android.material.bottomsheet.BottomSheetDialog diaalog4 = new com.google.android.material.bottomsheet.BottomSheetDialog(this);
								yes2.setOnClickListener(new OnClickListener() { 
									public void onClick(View v) 
									{
										if (SKUPMap.get("isCancelable").toString().equals("true")) 
										{ 
											Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
											startActivity(SketchUpdateIntent);
										} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
										{
											Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
											startActivity(SketchUpdateIntent);
											finishAffinity();
										}
									}
								});
								no2.setOnClickListener(new OnClickListener() { 
									public void onClick(View v) 
									{
										if (SKUPMap.get("extraBtn").toString().equals("exit")) 
										{
											finishAffinity();
										} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
										{    
											diaalog4.dismiss();  
										}
									}
								});
								diaalog4.setContentView(layllout2);
								diaalog4.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
								if (SKUPMap.get("isCancelable").toString().equals("true")) {
									diaalog4.setCancelable(true);
								}
								else {
									diaalog4.setCancelable(false);
								}
								diaalog4.show();
							}
						}
					}
					else {
						if (SKUPMap.get("alertType").toString().equals("dialog3") || SKUPMap.get("alertType").toString().equals("sheet3")) {
							LinearLayout layllout3 = new LinearLayout(this);
							
							layllout3.setOrientation(LinearLayout.VERTICAL);
							
							layllout3.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
							
							layllout3.setPadding(20,20,20,20);
							
							ImageView logo3 = new ImageView(this);
							
							logo3.setLayoutParams(new LinearLayout.LayoutParams(80,80, 0.0f));
							
							logo3.setTranslationY((float)(40));
							ImageView logo4 = new ImageView(this);
							
							logo4.setLayoutParams(new LinearLayout.LayoutParams(80,80, 0.0f));
							
							logo4.setTranslationY((float)(-40));
							
							Glide.with(getApplicationContext()).load(Uri.parse(SKUPMap.get("appIcon").toString())).into(logo3);
							
							Glide.with(getApplicationContext()).load(Uri.parse(SKUPMap.get("appIcon").toString())).into(logo4);
							LinearLayout lineear4 = new LinearLayout(this);
							
							lineear4.setOrientation(LinearLayout.HORIZONTAL);
							lineear4.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
							
							lineear4.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
							
							lineear4.setPadding(0,0,0,0);
							
							lineear4.addView(logo3);
							
							LinearLayout main3 = new LinearLayout(this);
							
							main3.setOrientation(LinearLayout.VERTICAL);
							
							main3.setGravity(Gravity.TOP | Gravity.LEFT);
							main3.setPadding(20,0,20,20);
							
							android.graphics.drawable.GradientDrawable skup22 = new android.graphics.drawable.GradientDrawable();
							skup22.setColor(Color.parseColor(backColor));
							skup22.setCornerRadius((float)radius);
							main3.setBackground(skup22);
							
							LinearLayout.LayoutParams params4 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,      
							LinearLayout.LayoutParams.MATCH_PARENT
							);
							main3.setLayoutParams(params4);
							LinearLayout lineear5 = new LinearLayout(this);
							
							lineear5.setOrientation(LinearLayout.HORIZONTAL);
							lineear5.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
							
							lineear5.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
							
							lineear5.setPadding(0,0,0,0);
							
							lineear5.addView(logo4);
							final TextView title3 = new TextView(this);
							
							title3.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
							
							title3.setPadding(0,20,0,5);
							
							title3.setText(SKUPMap.get("title").toString());
							title3.setTextSize((int)18);
							title3.setTypeface(null, Typeface.BOLD);
							
							title3.setTextColor(Color.parseColor(titleColor));
							TextView subtitle3 = new TextView(this);
							
							subtitle3.setPadding(0,0,0,20);
							
							subtitle3.setText(SKUPMap.get("subtitle").toString().concat("                                                                 "));
							subtitle3.setTextSize((int)14);
							final TextView description3 = new TextView(this);
							
							description3.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
							
							description3.setGravity(Gravity.TOP | Gravity.LEFT);
							
							description3.setText(SKUPMap.get("description").toString());
							
							description3.setTextSize((int)14);
							
							description3.setTextColor(Color.parseColor(descriptionColor));
							if (SKUPMap.get("isSubtitle").toString().equals("true")) {
								main3.addView(lineear5, 0);
								main3.addView(title3, 1);
								main3.addView(subtitle3, 2);
								main3.addView(description3, 3);
							}
							else {
								main3.addView(lineear5, 0);
								main3.addView(title3, 1);
								main3.addView(description3, 2);
							}
							
							Button no3 = new Button(this);
							
							no3.setText(SKUPMap.get("extraBtnTxt").toString());
							no3.setTextSize((int)14);
							
							android.graphics.drawable.GradientDrawable skup23 = new android.graphics.drawable.GradientDrawable();
							skup23.setColor(Color.parseColor(extraBtnBackColor));
							skup23.setCornerRadius((float)btnRadius);
							no3.setBackground(skup23);
							
							no3.setTextColor(Color.parseColor(extraBtnTxtColor));
							
							LinearLayout.LayoutParams params5 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,      
							LinearLayout.LayoutParams.WRAP_CONTENT);
							params5.setMargins(0, 20, 0, 0);
							no3.setLayoutParams(params5);
							Button yes3 = new Button(this);
							
							yes3.setText(SKUPMap.get("mainBtnTxt").toString());
							yes3.setTextSize((int)14);
							
							android.graphics.drawable.GradientDrawable skup24 = new android.graphics.drawable.GradientDrawable();
							skup24.setColor(Color.parseColor(mainBtnBackColor));
							skup24.setCornerRadius((float)btnRadius);
							yes3.setBackground(skup24);
							
							yes3.setTextColor(Color.parseColor(mainBtnTxtColor));
							
							LinearLayout.LayoutParams params6 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,      
							LinearLayout.LayoutParams.WRAP_CONTENT);
							params6.setMargins(0, 20, 0, 0);
							yes3.setLayoutParams(params6);
							
							if (SKUPMap.get("isExtraBtn").toString().equals("true")) {
								if (SKUPMap.get("isHeader").toString().equals("true")) {
									layllout3.addView(lineear4, 0);
									layllout3.addView(main3, 1);
									layllout3.addView(no3, 2);
									layllout3.addView(yes3, 3);
								}
								else {
									main3.removeView(lineear5);
									layllout3.addView(main3, 0);
									layllout3.addView(no3, 1);
									layllout3.addView(yes3, 2);
								}
							}
							else {
								if (SKUPMap.get("isHeader").toString().equals("true")) {
									layllout3.addView(lineear4, 0);
									layllout3.addView(main3, 1);
									layllout3.addView(yes3, 2);
								}
								else {
									main3.removeView(lineear5);
									layllout3.addView(main3, 0);
									layllout3.addView(yes3, 1);
								}
							}
							
							if (SKUPMap.get("newVersion").toString().equals(currentVersion)) {
									
							}
							else {
									if (SKUPMap.get("isOneTime").toString().equals("true")) {
											if ((SKUP.getString("isOneTime", "").equals(SKUPMap.get("isOneTime").toString()))) {
													
											}
									else {
										SKUP.edit().putString("isOneTime", SKUPMap.get("isOneTime").toString()).commit();
										if (SKUPMap.get("alertType").toString().equals("dialog3")) {
											final Dialog diaalog5 = new Dialog(this);
											diaalog5.requestWindowFeature(Window.FEATURE_NO_TITLE);
											diaalog5.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
											yes3.setOnClickListener(new OnClickListener() { 
												public void onClick(View v) 
												{
													if (SKUPMap.get("isCancelable").toString().equals("true")) 
													{ 
														Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
														startActivity(SketchUpdateIntent);
													} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
													{
														Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
														startActivity(SketchUpdateIntent);
														finishAffinity();
													}
												}
											});
											no3.setOnClickListener(new OnClickListener() { 
												public void onClick(View v) 
												{
													
													if (SKUPMap.get("extraBtn").toString().equals("exit")) 
													{
														finishAffinity();
													} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
													{    
														diaalog5.dismiss();  
													}
													
												}
											});
											diaalog5.setContentView(layllout3);
											if (SKUPMap.get("isCancelable").toString().equals("true")) {
												diaalog5.setCancelable(true);
											}
											else {
												diaalog5.setCancelable(false);
											}
											diaalog5.show();
										}
										else {
											final com.google.android.material.bottomsheet.BottomSheetDialog diaalog6 = new com.google.android.material.bottomsheet.BottomSheetDialog(this);
											yes3.setOnClickListener(new OnClickListener() { 
												public void onClick(View v) 
												{
													if (SKUPMap.get("isCancelable").toString().equals("true")) 
													{ 
														Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
														startActivity(SketchUpdateIntent);
													} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
													{
														Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
														startActivity(SketchUpdateIntent);
														finishAffinity();
													}
												}
											});
											no3.setOnClickListener(new OnClickListener() { 
												public void onClick(View v) 
												{
													if (SKUPMap.get("extraBtn").toString().equals("exit")) 
													{
														finishAffinity();
													} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
													{    
														diaalog6.dismiss();  
													}
												}
											});
											diaalog6.setContentView(layllout3);
											diaalog6.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
											if (SKUPMap.get("isCancelable").toString().equals("true")) {
												diaalog6.setCancelable(true);
												diaalog6.show();
											}
											else {
												diaalog6.setCancelable(false);
											}
											diaalog6.show();
										}
									}
								} else 
								if (SKUPMap.get("alertType").toString().equals("dialog3")) {
									final Dialog diaalog5 = new Dialog(this);
									diaalog5.requestWindowFeature(Window.FEATURE_NO_TITLE);
									diaalog5.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
									yes3.setOnClickListener(new OnClickListener() { 
										public void onClick(View v) 
										{
											if (SKUPMap.get("isCancelable").toString().equals("true")) 
											{ 
												Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
												startActivity(SketchUpdateIntent);
											} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
											{
												Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
												startActivity(SketchUpdateIntent);
												finishAffinity();
											}
										}
									});
									no3.setOnClickListener(new OnClickListener() { 
										public void onClick(View v) 
										{
											if (SKUPMap.get("extraBtn").toString().equals("exit")) 
											{
												finishAffinity();
											} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
											{    
												diaalog5.dismiss();  
											}
										}
									});
									diaalog5.setContentView(layllout3);
									if (SKUPMap.get("isCancelable").toString().equals("true")) {
										diaalog5.setCancelable(true);
									}
									else {
										diaalog5.setCancelable(false);
									}
									diaalog5.show();
								}
								else {
									final com.google.android.material.bottomsheet.BottomSheetDialog diaalog6 = new com.google.android.material.bottomsheet.BottomSheetDialog(this);
									yes3.setOnClickListener(new OnClickListener() { 
										public void onClick(View v) 
										{
											if (SKUPMap.get("isCancelable").toString().equals("true")) 
											{ 
												Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
												startActivity(SketchUpdateIntent);
											} else if (SKUPMap.get("isCancelable").toString().equals("false")) 
											{
												Intent SketchUpdateIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(SKUPMap.get("mainBtn").toString()));
												startActivity(SketchUpdateIntent);
												finishAffinity();
											}
										}
									});
									no3.setOnClickListener(new OnClickListener() { 
										public void onClick(View v) 
										{
											if (SKUPMap.get("extraBtn").toString().equals("exit")) 
											{
												finishAffinity();
											} else if (SKUPMap.get("extraBtn").toString().equals("dismiss")) 
											{    
												diaalog6.dismiss();  
											}
										}
									});
									diaalog6.setContentView(layllout3);
									diaalog6.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
									if (SKUPMap.get("isCancelable").toString().equals("true")) {
										diaalog6.setCancelable(true);
									}
									else {
										diaalog6.setCancelable(false);
									}
									diaalog6.show();
								}
							}
						}
						else {
							
						}
					}
				}
			}
			else {
			} 
		}
		else {
			
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}